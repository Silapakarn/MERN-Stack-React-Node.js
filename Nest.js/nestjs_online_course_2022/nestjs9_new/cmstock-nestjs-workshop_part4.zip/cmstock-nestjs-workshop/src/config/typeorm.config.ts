import { TypeOrmModuleOptions } from '@nestjs/typeorm';
export const typeOrmConfig: TypeOrmModuleOptions = {
  type: 'postgres',
  host: 'localhost',
  port: 5432,
  username: 'postgres',
  password: 'postgres',
  database: 'cmstock',
  autoLoadEntities: true, // true เพื่อให้มัน auto load entity เพื่อให้พร้อมใช้งาน
  synchronize: true,
};
