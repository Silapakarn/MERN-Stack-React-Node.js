import { User } from './user.entity';
import { UserCredentailDto } from './dto/user-credential.dto';
import {
  ConflictException,
  Injectable,
  InternalServerErrorException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User) private userRepository: Repository<User>,
  ) {}

  async createUser(userCredentialDto: UserCredentailDto) {
    const { username, password } = userCredentialDto;
    const salt = bcrypt.genSaltSync();

    const user = new User();
    user.username = username;
    user.salt = salt;
    user.password = await this.hashPassword(password, salt);

    try {
      await user.save();
    } catch (error) {
      console.log(error);
      if (error.code === '23505') {
        throw new ConflictException(
          'Error, because this username already exist!',
        );
      } else {
        throw new InternalServerErrorException();
      }
    }

    return user;
  }

  async verifyUserPassword(userCredentialDto: UserCredentailDto) {
    const { username, password } = userCredentialDto;
    const user = await this.userRepository.findOne({ where: { username } });
    if (user && (await user.verifyPassword(password))) {
      return user.username;
    } else {
      return 'invalid';
    }
  }

  async hashPassword(password: string, salt: string) {
    return bcrypt.hash(password, salt);
  }

  signUp(userCredentialDto: UserCredentailDto) {
    return this.createUser(userCredentialDto);
  }

  signIn(userCredentialDto: UserCredentailDto) {
    return this.verifyUserPassword(userCredentialDto);
  }
}
