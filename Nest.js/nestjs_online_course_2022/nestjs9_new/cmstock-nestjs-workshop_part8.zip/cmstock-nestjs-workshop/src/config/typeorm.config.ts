import { TypeOrmModuleOptions } from '@nestjs/typeorm';
import * as config from 'config';

const dbConfig = config.get('db');
console.log(dbConfig);

export const typeOrmConfig: TypeOrmModuleOptions = {
  type: 'postgres',
  host: 'localhost',
  port: 5432,
  username: dbConfig.username,
  password: dbConfig.password,
  database: 'cmstock',
  autoLoadEntities: true, // true เพื่อให้มัน auto load entity เพื่อให้พร้อมใช้งาน
  synchronize: true,
};
