import { ProductRepository } from './product.repository';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Module } from '@nestjs/common';
import { StockController } from './stock.controller';

@Module({
  imports: [TypeOrmModule.forFeature([ProductRepository])],
  controllers: [StockController],
})
export class StockModule { }
