import { ProductRepository } from './product.repository';
import { Product } from './product.entity';
import { ChangeStringCasePipe } from './../pipes/change-string-case.pipe';
import { CreateStockDto } from './dto/create-stock-dto';
import { Controller, Get, Post, Body, UsePipes, ValidationPipe, Param, Delete, Patch, Put, HttpException, HttpStatus, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';

@Controller('stock')
export class StockController {

    constructor(@InjectRepository(ProductRepository) private productRepository:ProductRepository){}

    @Get()
    getStocks() {

        // throw new HttpException({
        //     status: HttpStatus.FORBIDDEN,
        //     error: 'This is a custom message',
        // }, HttpStatus.FORBIDDEN);

        // return [1, 2, 3]
        return this.productRepository.find()
    }

    // @Post()
    // addStock(@Body('name') name:string, @Body('price') price:number){

    //     console.log(`${name}, ${price}`)
    // }

    @Post()
    @UsePipes(ValidationPipe)
    @UsePipes(new ChangeStringCasePipe())
    addStock(@Body() createStockDto: CreateStockDto) {

        const { name, price, stock } = createStockDto
        console.log(`${name}, ${price}, ${stock}`)

        const product = new Product()
        product.name = name
        product.price = price
        product.stock = stock
        product.save()
    }

    @Get('/:id')
    getStockById(@Param('id') id: number) {
        return `Get Id is ${id}`
    }

    @Delete('/:id')
    DeleteStockById(@Param('id') id: number) {
        return `Delete Id is ${id}`
    }

    @Put('/:id')
    UpdateStockById(@Param('id') id: number, @Body() createStockDto: CreateStockDto) {
        const { name, price, stock } = createStockDto
        console.log(`${name}, ${price}, ${stock}`)

        return `Update Id is ${id},  ${name}, ${price}, ${stock}`
    }

}
