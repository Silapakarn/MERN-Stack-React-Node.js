export class Todo {
    id:string;
    title:string;
    subtitle:string;
}