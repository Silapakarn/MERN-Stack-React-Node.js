import { UserCredentailDto } from './dto/user-credential.dto';
import { Controller, Post, Body, UsePipes, ValidationPipe } from '@nestjs/common';
import { AuthService } from './auth.service';

@Controller('auth')
export class AuthController {
    constructor(private authenService: AuthService) { }

    // {"username":"admin", "password":"12345678aA!"}
    @Post('/signup')
    @UsePipes(ValidationPipe)
    signUp(@Body() userCredential: UserCredentailDto) {
        console.log(userCredential)
        return this.authenService.signUp(userCredential)
    }

    @Post('/signin')
    signIn(@Body() userCredential: UserCredentailDto) {
        console.log(userCredential)
        return this.authenService.signIn(userCredential)
    }
}
