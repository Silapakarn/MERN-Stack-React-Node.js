import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { loggerFn } from './logger.fn.middleware';
import * as config from 'config';


async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  // app.use(loggerFn)  

  const serverConfig = config.get("server")

  if (process.env.NODE_ENV === 'development') {
    app.enableCors();
  } else {
    app.enableCors({ origin: process.env.ORIGIN || serverConfig.origin })
    console.log("Accepting Origin : " + serverConfig.origin)
  }


  console.log("CMStockStarting..1#")
  console.log(process.env.PORT || serverConfig.port)

  await app.listen(process.env.PORT || serverConfig.port);
}
bootstrap();
