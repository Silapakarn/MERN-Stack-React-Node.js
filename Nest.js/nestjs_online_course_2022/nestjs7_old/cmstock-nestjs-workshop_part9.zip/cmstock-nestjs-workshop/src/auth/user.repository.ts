import { UserCredentailDto } from './dto/user-credential.dto';
import { User } from './user.entity';
import { Repository, EntityRepository } from "typeorm";
import { ConflictException, InternalServerErrorException } from '@nestjs/common';
import * as bcrypt from "bcryptjs";

@EntityRepository(User)
export class UserRepository extends Repository<User>{

    async createUser(userCredentialDto: UserCredentailDto) {
        const { username, password } = userCredentialDto
        const salt = bcrypt.genSaltSync();


        const user = new User()
        user.username = username;
        user.salt = salt;
        user.password = await this.hashPassword(password, salt);

        try {
            await user.save()
        } catch (error) {
            console.log(error)
            if (error.code === '23505') {
                throw new ConflictException("Error, because this username already exist!")
            } else {
                throw new InternalServerErrorException();
            }
        }

        return user;
    }

    async verifyUserPassword(userCredentialDto: UserCredentailDto) {
        const { username, password } = userCredentialDto;
        const user = await this.findOne({ username })
        console.log(user.verifyPassword(password))
        if (user && await user.verifyPassword(password)) {
            return user.username
        } else {
            return null
        }
    }


    async hashPassword(password: string, salt: string) {
        return bcrypt.hash(password, salt)
    }
}